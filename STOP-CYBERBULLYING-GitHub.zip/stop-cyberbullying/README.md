# STOP CYBERBULLYING

Website edukasi dan pencegahan cyberbullying dengan HTML, CSS, JavaScript, Firebase Authentication, dan Cloud Firestore.

## Isi folder
- `index.html` — struktur halaman dan konten edukasi.
- `css/style.css` — tampilan responsif.
- `js/firebase-config.js` — konfigurasi proyek Firebase (wajib diisi).
- `js/app.js` — login, registrasi, logout, kuis, dan penyimpanan nilai.
- `firestore.rules` — aturan keamanan database Firestore.

## 1. Siapkan Firebase

1. Buka https://console.firebase.google.com/ lalu login dengan akun Google.
2. Pilih **Add project / Tambahkan project**, beri nama misalnya `stop-cyberbullying`.
3. Setelah proyek dibuat, klik ikon Web `</>` untuk menambahkan aplikasi web.
4. Beri nama aplikasi, lalu daftarkan. Firebase akan menampilkan konfigurasi `firebaseConfig`.
5. Salin nilai `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, dan `appId`.
6. Buka `js/firebase-config.js` dan ganti semua nilai `GANTI_...` dengan nilai dari Firebase Console. Jangan mengubah nama properti.
7. Di Firebase Console, buka **Build > Authentication > Get started > Sign-in method**. Aktifkan **Email/Password**, lalu simpan.
8. Buka **Authentication > Settings > Authorized domains**. Pastikan domain GitHub Pages milikmu ditambahkan, misalnya `username.github.io` (domain default Firebase biasanya sudah ada).
9. Buka **Build > Firestore Database > Create database**. Pilih lokasi database yang sesuai. Untuk tugas sekolah, pilih mode production.
10. Buka tab **Rules**, ganti aturan dengan isi file `firestore.rules`, lalu klik **Publish**.

> Catatan: Firebase web config memang berada di sisi browser. Keamanan data tidak bergantung pada menyembunyikan config, tetapi pada Authentication dan Firestore Security Rules. Jangan pernah memasukkan service account private key atau kredensial admin ke website.

## 2. Jalankan website

Karena kode menggunakan JavaScript module, jangan membuka `index.html` langsung dengan `file://`. Jalankan melalui server lokal atau GitHub Pages.

Cara mudah:
- Pasang ekstensi **Live Server** di Visual Studio Code.
- Buka folder proyek di VS Code.
- Klik kanan `index.html` > **Open with Live Server**.

## 3. Upload ke GitHub

1. Login ke https://github.com/.
2. Klik **New repository**.
3. Isi nama repository, misalnya `stop-cyberbullying`.
4. Pilih **Public**, lalu klik **Create repository**.
5. Upload seluruh isi folder proyek (jangan hanya file `index.html`).
6. Pastikan struktur di repository seperti ini:

```text
stop-cyberbullying/
├── index.html
├── README.md
├── firestore.rules
├── css/
│   └── style.css
└── js/
    ├── app.js
    └── firebase-config.js
```

## 4. Aktifkan GitHub Pages

1. Buka repository GitHub.
2. Pilih **Settings > Pages**.
3. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
4. Pilih branch `main` dan folder `/(root)`.
5. Klik **Save**.
6. Tunggu proses deployment. Alamat website biasanya:
   `https://USERNAME.github.io/NAMA-REPOSITORY/`
7. Tambahkan `USERNAME.github.io` ke Firebase Authentication > Settings > Authorized domains jika belum terdaftar.

## 5. Tes fitur

- Buka website melalui alamat GitHub Pages.
- Klik **Daftar**, isi nama, email, dan password minimal 6 karakter.
- Setelah berhasil, coba keluar lalu masuk kembali.
- Selesaikan kuis. Jika login, hasil terakhir tersimpan di koleksi `quizResults`.
- Periksa Firebase Console > Authentication untuk daftar akun dan Firestore Database untuk data.

## Catatan penting
- Ini adalah website edukasi, bukan layanan pengaduan darurat atau pengganti bantuan profesional.
- Jangan meminta atau menampilkan data sensitif pengunjung.
- Hasil kuis yang disimpan adalah hasil terakhir per pengguna, bukan riwayat setiap percobaan.
- Website memerlukan koneksi internet untuk memuat Firebase SDK dan Google Fonts.
- Jika halaman login gagal, periksa konfigurasi Firebase, metode Email/Password, authorized domains, dan aturan Firestore.
