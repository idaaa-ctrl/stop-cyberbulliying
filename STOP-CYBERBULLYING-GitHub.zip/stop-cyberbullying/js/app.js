import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, doc, setDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const $ = (id) => document.getElementById(id);
const modal = $("auth-modal");
const authForm = $("auth-form");
const authMessage = $("auth-message");
let authMode = "login";
let currentUser = null;
let toastTimer;

const configReady = Object.values(firebaseConfig).every(value =>
  typeof value === "string" && value.length > 0 && !value.startsWith("GANTI_")
);

let auth = null;
let db = null;
if (configReady) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} else {
  console.warn("Konfigurasi Firebase belum diisi. Lengkapi js/firebase-config.js terlebih dahulu.");
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}
function setAuthMessage(message, success = false) {
  authMessage.textContent = message;
  authMessage.classList.toggle("success", success);
}
function openModal(mode = "login") {
  setAuthMode(mode);
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}
function closeModal() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
  setAuthMessage("");
}
function setAuthMode(mode) {
  authMode = mode;
  const register = mode === "register";
  $("auth-title").textContent = register ? "Buat akun baru" : "Masuk ke akunmu";
  $("auth-subtitle").textContent = register
    ? "Daftar untuk menyimpan perjalanan belajarmu."
    : "Lanjutkan perjalananmu menjadi pengguna digital yang bijak.";
  $("name-field").classList.toggle("hidden", !register);
  $("display-name").required = register;
  $("password").autocomplete = register ? "new-password" : "current-password";
  $("auth-submit").textContent = register ? "Daftar sekarang" : "Masuk";
  $("login-tab").classList.toggle("active", !register);
  $("register-tab").classList.toggle("active", register);
  setAuthMessage("");
}

$("open-auth").addEventListener("click", () => openModal("login"));
$("hero-auth").addEventListener("click", () => openModal("register"));
$("close-auth").addEventListener("click", closeModal);
$("modal-backdrop").addEventListener("click", closeModal);
$("login-tab").addEventListener("click", () => setAuthMode("login"));
$("register-tab").addEventListener("click", () => setAuthMode("register"));

function friendlyError(error) {
  const messages = {
    "auth/email-already-in-use": "Email ini sudah terdaftar. Silakan masuk.",
    "auth/invalid-email": "Format email belum benar.",
    "auth/weak-password": "Password terlalu lemah. Gunakan minimal 6 karakter.",
    "auth/invalid-credential": "Email atau password salah.",
    "auth/user-not-found": "Akun tidak ditemukan. Periksa email atau daftar dahulu.",
    "auth/wrong-password": "Password tidak sesuai.",
    "auth/too-many-requests": "Terlalu banyak percobaan. Coba lagi nanti.",
    "auth/network-request-failed": "Koneksi internet bermasalah. Coba lagi."
  };
  return messages[error.code] || "Terjadi kesalahan. Periksa koneksi dan konfigurasi Firebase.";
}

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!configReady || !auth) {
    setAuthMessage("Firebase belum dikonfigurasi. Isi js/firebase-config.js sesuai panduan README.");
    return;
  }
  const email = $("email").value.trim();
  const password = $("password").value;
  const name = $("display-name").value.trim();
  const submit = $("auth-submit");
  submit.disabled = true;
  submit.textContent = "Memproses...";
  setAuthMessage("");
  try {
    if (authMode === "register") {
      if (name.length < 2) throw new Error("Nama harus terdiri dari minimal 2 karakter.");
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName: name });
      await setDoc(doc(db, "users", credential.user.uid), {
        displayName: name,
        email,
        createdAt: serverTimestamp()
      });
      setAuthMessage("Akun berhasil dibuat. Selamat belajar!", true);
    } else {
      await signInWithEmailAndPassword(auth, email, password);
      setAuthMessage("Login berhasil!", true);
    }
    setTimeout(closeModal, 650);
  } catch (error) {
    setAuthMessage(error.message && !error.code ? error.message : friendlyError(error));
  } finally {
    submit.disabled = false;
    submit.textContent = authMode === "register" ? "Daftar sekarang" : "Masuk";
  }
});

$("logout-button").addEventListener("click", async () => {
  if (!auth) return;
  try {
    await signOut(auth);
    showToast("Kamu berhasil keluar dari akun.");
  } catch {
    showToast("Tidak dapat keluar. Coba lagi.");
  }
});

if (auth) {
  onAuthStateChanged(auth, (user) => {
    currentUser = user;
    $("open-auth").classList.toggle("hidden", !!user);
    $("logout-button").classList.toggle("hidden", !user);
    $("user-label").classList.toggle("hidden", !user);
    $("user-label").textContent = user ? `Halo, ${user.displayName || user.email}` : "";
  });
}

// Kuis interaktif
const questions = [
  { q: "Apa yang sebaiknya dilakukan saat melihat teman menjadi korban cyberbullying?", options: ["Ikut membagikan konten tersebut", "Mendukung teman dan membantu mencari orang dewasa tepercaya", "Membalas pelaku dengan hinaan"], answer: 1, explain: "Benar! Berikan dukungan dan bantu teman mencari pertolongan yang aman." },
  { q: "Manakah contoh perilaku cyberbullying?", options: ["Memberi kritik dengan sopan", "Mengirim pesan berisi hinaan berulang kali", "Melaporkan akun palsu"], answer: 1, explain: "Tepat. Pesan yang menghina atau mengintimidasi termasuk bentuk cyberbullying." },
  { q: "Apa tindakan yang tepat jika menerima pesan perundungan?", options: ["Simpan bukti, blokir/laporkan, dan ceritakan kepada orang tepercaya", "Sebarkan identitas pelaku", "Balas dengan ancaman"], answer: 0, explain: "Betul. Simpan bukti secara aman dan minta bantuan orang dewasa tepercaya." },
  { q: "Sebelum mengunggah foto teman, sebaiknya kita...", options: ["Langsung mengunggahnya", "Meminta izin terlebih dahulu", "Mengeditnya agar lucu tanpa bertanya"], answer: 1, explain: "Benar. Hormati privasi dan minta persetujuan sebelum membagikan foto orang lain." }
];
let questionIndex = 0;
let score = 0;
let selectedAnswer = null;
let answered = false;

function renderQuestion() {
  const item = questions[questionIndex];
  $("quiz-question").textContent = item.q;
  $("quiz-progress").textContent = `Pertanyaan ${questionIndex + 1} dari ${questions.length}`;
  $("progress-fill").style.width = `${((questionIndex + 1) / questions.length) * 100}%`;
  $("quiz-feedback").textContent = "";
  $("next-question").disabled = true;
  $("next-question").textContent = questionIndex === questions.length - 1 ? "Lihat hasil" : "Selanjutnya →";
  $("restart-quiz").classList.add("hidden");
  $("quiz-options").innerHTML = "";
  item.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "quiz-option";
    button.textContent = `${String.fromCharCode(65 + index)}. ${option}`;
    button.addEventListener("click", () => chooseAnswer(index));
    $("quiz-options").appendChild(button);
  });
  answered = false;
  selectedAnswer = null;
}
function chooseAnswer(index) {
  if (answered) return;
  answered = true;
  selectedAnswer = index;
  const item = questions[questionIndex];
  if (index === item.answer) score++;
  [...$("quiz-options").children].forEach((button, i) => {
    button.disabled = true;
    if (i === item.answer) button.classList.add("correct");
    else if (i === index) button.classList.add("wrong");
  });
  $("quiz-feedback").textContent = index === item.answer ? item.explain : `Belum tepat. ${item.explain}`;
  $("next-question").disabled = false;
}
$("next-question").addEventListener("click", async () => {
  if (!answered) return;
  if (questionIndex < questions.length - 1) {
    questionIndex++;
    renderQuestion();
    return;
  }
  $("quiz-question").textContent = `Skormu ${score} dari ${questions.length}!`;
  $("quiz-options").innerHTML = `<p class="muted">${score === questions.length ? "Luar biasa! Kamu memahami dasar-dasar keamanan digital." : "Terus belajar dan ingat untuk selalu menghargai orang lain di dunia digital."}</p>`;
  $("quiz-feedback").textContent = "Terima kasih sudah mengikuti kuis.";
  $("next-question").classList.add("hidden");
  $("restart-quiz").classList.remove("hidden");
  if (currentUser && db) {
    try {
      await setDoc(doc(db, "quizResults", currentUser.uid), {
        score,
        total: questions.length,
        completedAt: serverTimestamp()
      });
      showToast("Hasil kuis tersimpan di akunmu.");
    } catch (error) {
      console.error(error);
      showToast("Kuis selesai, tetapi hasil belum dapat disimpan.");
    }
  } else {
    showToast("Masuk untuk menyimpan hasil kuis.");
  }
});
$("restart-quiz").addEventListener("click", () => {
  questionIndex = 0; score = 0;
  $("next-question").classList.remove("hidden");
  renderQuestion();
});
renderQuestion();
